<%@page import="java.text.SimpleDateFormat"%>
<%@page import="models.MessageBean"%>
<%@page import="java.util.List"%>
<%@page import="models.MessageDAO"%>
<%@page import="models.UserBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Blindagem ativa: Restringe o acesso visual estritamente a administradores logados
    HttpSession sessaoAdmin = request.getSession(false);
    UserBean adminLogado = (sessaoAdmin != null) ? (UserBean) sessaoAdmin.getAttribute("user") : null;

    if (adminLogado == null || !"adm".equalsIgnoreCase(adminLogado.getUserType())) {
        response.sendRedirect(request.getContextPath() + "/pagina?p=home");
        return;
    }

    // Captura o filtro de status selecionado na URL (ex: ?status=pendente)
    String statusFiltro = request.getParameter("status");
    MessageDAO msgDao = new MessageDAO();
    List<MessageBean> mensagens = msgDao.getAllMessages(statusFiltro);

    // Formatador de estampa de tempo
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
%>

<div class="container" style="margin-top: 80px; margin-bottom: 50px;">
    <h2>Gerenciador de Mensagens de Contato</h2>

    <%-- FEEDBACK DE AÇÕES: Alertas de status despachados pelo AdminServlet --%>
    <% if ("success".equals(request.getParameter("msg"))) { %>
    <p style="color: #28a745; font-weight: bold; margin-bottom: 15px;">Mensagem marcada como Resolvida com sucesso!</p>
    <% } else if ("deleted".equals(request.getParameter("msg"))) { %>
    <p style="color: #28a745; font-weight: bold; margin-bottom: 15px;">Mensagem excluída permanentemente.</p>
    <% } else if ("error".equals(request.getParameter("msg"))) { %>
    <p style="color: #dc3545; font-weight: bold; margin-bottom: 15px;">Erro ao processar operação na mensagem.</p>
    <% } %>

    <%-- Barra de Filtros por Status (Estilizados via style1.css) --%>
    <div style="margin-bottom: 20px; display: flex; gap: 8px; flex-wrap: wrap;">
        <a class="btn" href="${pageContext.request.contextPath}/pagina?p=admin_messages" style="margin-top:0;">Todas</a>
        <a class="btn" href="${pageContext.request.contextPath}/pagina?p=admin_messages&status=pendente" style="margin-top:0; background:#ffc107;">Pendentes</a>
        <a class="btn" href="${pageContext.request.contextPath}/pagina?p=admin_messages&status=lida" style="margin-top:0; background:#6c757d;">Lidas</a>
        <a class="btn" href="${pageContext.request.contextPath}/pagina?p=admin_messages&status=resolvida" style="margin-top:0; background:#28a745;">Resolvidas</a>
    </div>

    <div class="table-container" style="margin-top: 20px;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data de Envio</th>
                    <th>Nome</th>
                    <th>Assunto</th>
                    <th style="text-align: center;">Status</th>
                    <th style="text-align: center;">Ações</th>
                </tr>
            </thead>
            <tbody>
                <% if (mensagens.isEmpty()) { %>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 20px; color: #c9c7c7;">Nenhuma mensagem encontrada.</td>
                </tr>
                <% } else { %>
                <% for (MessageBean msg : mensagens) {%>
                <tr>
                    <td><%= msg.getId()%></td>
                    <td><%= sdf.format(msg.getCreatedAt())%></td>
                    <td><%= msg.getName()%></td>
                    <td><%= msg.getSubject()%></td>
                    <td style="text-align: center;">
                        <%-- Classe identificadora badge-status utilizada pelo script AJAX --%>
                        <span class="badge-status" style="padding: 3px 8px; border-radius: 4px; font-size: 0.85em; font-weight: bold; color: white; background-color:
                              <%= "resolvida".equalsIgnoreCase(msg.getStatus()) ? "#28a745" : ("lida".equalsIgnoreCase(msg.getStatus()) ? "#6c757d" : "#ffc107")%>;">
                            <%= msg.getStatus().toUpperCase()%>
                        </span>
                    </td>
                    <td style="text-align: center;">
                        <div style="display: flex; justify-content: center; gap: 10px;">
                            
                            <button type="button" class="btn btn-ler" style="padding: 5px 12px;"
                                    data-id="<%= msg.getId()%>"
                                    data-name="<%= msg.getName()%>"
                                    data-subject="<%= msg.getSubject()%>"
                                    data-message="<%= msg.getMessage()%>">
                                👁️ Ler
                            </button>

                            <% if (!"resolvida".equalsIgnoreCase(msg.getStatus())) {%>
                            <a class="btn"  href="${pageContext.request.contextPath}/admin/resolver-mensagem?id=<%= msg.getId()%>" 
                               style="background-color: #28a745; color: white; padding: 6px 12px; border-radius: 5px; text-decoration: none; font-size: 0.95rem; font-weight: 600;" 
                               onclick="return confirm('Marcar mensagem como Resolvida?')">✅ Resolver</a>
                            <% }%>

                            <a class="btn" href="${pageContext.request.contextPath}/admin/deletar-mensagem?id=<%= msg.getId()%>" 
                               style="background-color: #dc3545; color: white; padding: 6px 12px; font-size: 0.95rem; font-weight: 600;"
                               onclick="return confirm('Tem certeza que deseja excluir esta mensagem?')">🗑️ Excluir</a>
                        </div>
                    </td>
                </tr>
                <% } %>
                <% }%>
            </tbody>
        </table>
    </div>
</div>

<%-- Estrutura da Janela Modal Oculta para Exibição de Conteúdo (Estilizada via style1.css) --%>
<div id="messageModal" class="custom-modal">
    <div class="custom-modal-content">
        <span class="close-modal">&times;</span>
        <h3>Mensagem de: <span id="modal-name"></span></h3>
        <p><strong>ID da Mensagem:</strong> <span id="modal-id"></span></p>
        <p><strong>Assunto:</strong> <span id="modal-subject"></span></p>
        <hr style="border: none; border-top: 1px solid rgba(255, 255, 255, 0.2); margin: 15px 0;">
        <p style="white-space: pre-wrap; background: rgba(0,0,0,0.3); padding: 15px; border-radius: 5px;" id="modal-message"></p>
    </div>
</div>

<%-- JAVASCRIPT INTEGRADO --%>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const modal = document.getElementById('messageModal');
        const closeBtn = document.querySelector('.close-modal');
        const readButtons = document.querySelectorAll('.btn-ler');

        readButtons.forEach(button => {
            button.addEventListener('click', function () {
                // 1. Extrai a coleção de dados embutida nas propriedades do botão
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const subject = this.getAttribute('data-subject');
                const message = this.getAttribute('data-message');

                // 2. Preenche os nós textuais da janela modal flutuante
                document.getElementById('modal-id').textContent = id;
                document.getElementById('modal-name').textContent = name;
                document.getElementById('modal-subject').textContent = subject;
                document.getElementById('modal-message').textContent = message;

                // 3. Modifica a propriedade de exibição para flutuar na tela
                modal.style.display = 'flex';

                // 4. MÁGICA DO AJAX: Localiza a célula de status na mesma linha da tabela
                const statusCell = this.closest('tr').querySelector('.badge-status');

                // Dispara a requisição de rede invisível se o status for estritamente 'pendente'
                if (statusCell.textContent.trim().toLowerCase() === 'pendente') {

                    // Dispara o AJAX invisível para a rota mapeada no AdminServlet Java
                    fetch('${pageContext.request.contextPath}/admin/marcar-lida', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({id: id})
                    })
                            .then(response => response.json())
                            .then(data => {
                                if (data.sucesso) {
                                    // 5. ATUALIZAÇÃO EM TEMPO DE EXECUÇÃO: Altera o texto e a cor do badge sem dar F5
                                    statusCell.textContent = 'LIDA';
                                    statusCell.style.backgroundColor = '#6c757d'; // Muda a cor para cinza (Status Lida)
                                }
                            });
                }
            });
        });

        // Gatilhos de fechamento da janela modal
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });
        }

        window.addEventListener('click', (event) => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
</script>

<jsp:include page="includes/footer.jsp" />
