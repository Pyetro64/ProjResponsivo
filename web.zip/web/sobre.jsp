<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="includes/header.jsp" %>

<section class="about-section" style="padding: 60px 20px; color: white;">
    <div class="container text-center">
        <h2 style="font-size: 2.5rem; margin-bottom: 40px;">Sobre o Projeto Responsivo</h2>
        <p style="max-width: 800px; margin: 20px auto; line-height: 1.6;">
            Este projeto foi desenvolvido pela turma de programação para demonstrar a aplicação
            prática do padrão <strong>MVC (Model-View-Controller)</strong> utilizando a arquitetura 
            <strong>Java Web (Servlets e JSP)</strong> integrada ao MySQL via JDBC.
        </p>

        <div class="team-img">
            <!-- Uso do Helper de Imagem -->
            <img src="${pageContext.request.contextPath}/assets/img/favicon.png"  alt="Logo Equipe" style="width: 100px;">
        </div>
    </div>
</section>

<%@include file="includes/footer.jsp" %>
