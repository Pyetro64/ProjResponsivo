<%@page import="java.util.Base64"%>
<%@page import="java.sql.Blob"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="models.Database"%>
<%@page import="java.sql.Connection"%>
<%@page import="models.UserBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Recupera os dados guardados em memória pela sessão aberta no login
    HttpSession sessao = request.getSession(false);
    UserBean usuarioLogado = (sessao != null) ? (UserBean) sessao.getAttribute("user") : null;

    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/pagina?p=login");
        return;
    }

    String fotoBase64 = null;
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
        conn = Database.getConnection();
        // Consulta para capturar a coluna binária vinculada à FK do usuário
        String sql = "SELECT foto_perfil FROM perfil WHERE user_id = ?";
        stmt = conn.prepareStatement(sql);
        stmt.setInt(1, usuarioLogado.getId());
        rs = stmt.executeQuery();

        if (rs.next()) {
            Blob blob = rs.getBlob("foto_perfil");
            // Lê os dados do BLOB em um vetor nativo de bytes
            if (blob != null) {
                byte[] imageBytes = blob.getBytes(1, (int) blob.length());
                // Transforma os bytes brutos em uma string estável Base64
                fotoBase64 = Base64.getEncoder().encodeToString(imageBytes);
            }
        }
    } catch (Exception e) {
        // CORREÇÃO: Utilizando o logger nativo do servidor JSP para evitar conflitos de tipo no compilador
        application.log("Erro ao carregar foto do perfil: " + e.getMessage(), e);
    } finally {
        // CORREÇÃO: Estrutura aninhada e segura que impede erros de compilação no bloco finally do Tomcat
        if (rs != null) {
            try { rs.close(); } catch (Exception e) { application.log("Erro ao fechar ResultSet: " + e.getMessage()); }
        }
        if (stmt != null) {
            try { stmt.close(); } catch (Exception e) { application.log("Erro ao fechar Statement: " + e.getMessage()); }
        }
        if (conn != null) {
            try { conn.close(); } catch (Exception e) { application.log("Erro ao fechar Connection: " + e.getMessage()); }
        }
    }
%>

<div class="container" style="margin-top: 80px; margin-bottom: 50px; max-width: 600px;">
    <h2 style="text-align: center; margin-bottom: 30px;">Perfil do Usuário</h2>

    <%-- Exibe mensagens de feedback de upload --%>
    <% if (request.getAttribute("msgPerfil") != null) {%>
    <p style="background: #e2e8f0; padding: 10px; border-radius: 4px; text-align: center; color: #333; margin-bottom: 20px;">
        <%= request.getAttribute("msgPerfil")%>
    </p>
    <% } %>

    <div class="card" style="text-align: center;">

        <div style="margin-bottom: 20px;">
            <% if (fotoBase64 != null) {%>
            <!-- RENDERIZAÇÃO DINÂMICA: Exibe a String Base64 convertida pelo Java diretamente no src -->
            <img class="profile-img" src="data:image/jpeg;base64,<%= fotoBase64%>" 
                 alt="Foto de Perfil" title="Foto de Perfil"
                 style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 3px solid #47b2e4;">
            <% } else { %>
            <img class="profile-img" src="${pageContext.request.contextPath}/assets/img/perfil_padrao.png" 
                 alt="Foto Padrão" title="Foto de Perfil"
                 style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 3px solid #ccc;">
            <% }%>
        </div>

        <h3 style="margin-bottom: 15px;"><%= usuarioLogado.getName()%></h3>
        <p style="margin: 5px 0;"><strong>Email:</strong> <%= usuarioLogado.getEmail()%></p>
        <p style="margin: 5px 0;"><strong>Tipo de Usuário:</strong> <%= usuarioLogado.getUserType()%></p>

        <hr style="margin: 25px 0; border: none; border-top: 1px solid #e2e8f0;">

        <h4 style="margin-bottom: 15px;">Alterar Foto de Perfil</h4>
        <!-- OBRIGÓRIO: enctype="multipart/form-data" avisa o navegador para despachar o arquivo em blocos binários -->
        <form action="${pageContext.request.contextPath}/profile" method="post" enctype="multipart/form-data" style="display: inline-block; text-align: left;">

            <input type="file" name="imagem" accept=".jpg, .jpeg, .png, .webp" required style="margin-bottom: 10px;"><br>
            <small style="display: block; margin-bottom: 20px;">
                Formato: JPG, PNG ou WEBP. Tamanho máx: 2MB.
            </small>

            <div style="text-align: center;">
                <button type="submit" class="btn btn-primary" style="background: #47b2e4; border: none; padding: 10px 20px; border-radius: 4px; color: #fff; cursor: pointer;">
                    Atualizar Foto
                </button>
            </div>
        </form>
    </div>
</div>

<jsp:include page="includes/footer.jsp" />
