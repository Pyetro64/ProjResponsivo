<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<div class="container" style="margin-top: 80px; margin-bottom: 50px; max-width: 450px;">
    <h2>Definir Nova Senha</h2>
    <%-- FEEDBACK VISUAL: Exibe caixas de alerta baseadas no retorno do processamento do Servlet --%>
    <% if (request.getAttribute("message") != null) {
            String type = (String) request.getAttribute("message_type");
            boolean isError = "error".equalsIgnoreCase(type);
    %>
    <div style="padding: 10px; margin-bottom: 15px; border-radius: 4px;
         background-color: <%= isError ? "#fee2e2" : "#dcfce7"%>;
         color: <%= isError ? "#991b1b" : "#166534"%>; font-weight: bold;">
        <%= request.getAttribute("message")%>
    </div>
    <% }%>
    <%-- Formulário que despacha os dados via POST para o endpoint do PasswordResetServlet --%>
    <form method="POST" action="${pageContext.request.contextPath}/recuperar-senha/alterar" style="padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0;">

        <div class="form-group" style="margin-bottom: 15px;">
            <label for="token" style="display: block; margin-bottom: 5px; font-weight: bold;">Código de Verificação (6 números):</label>
            <input type="text" id="token" name="token" pattern="\d{6}" maxlength="6" placeholder="Ex: 123456" required autocomplete="off" 
                   style="text-align: center; font-size: 20px; letter-spacing: 4px; font-weight: bold; width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;">
        </div>

        <div class="form-group" style="margin-bottom: 15px;">
            <label for="new_password" style="display: block; margin-bottom: 5px; font-weight: bold;">Nova Senha:</label>
            <input type="password" id="new_password" name="new_password" required class="form-control" placeholder="Mínimo 6 caracteres" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;">
        </div>

        <div class="form-group" style="margin-bottom: 20px;">
            <label for="confirm_password" style="display: block; margin-bottom: 5px; font-weight: bold;">Confirme a Nova Senha:</label>
            <input type="password" id="confirm_password" name="confirm_password" required class="form-control" placeholder="Repita a nova senha" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;">
        </div>

        <button class="btn btn-primary" type="submit" style="background: #28a745; border: none; padding: 10px 20px; border-radius: 4px; color: white; cursor: pointer; font-weight: bold; width: 100%;">
            Salvar Nova Senha
        </button>
    </form>
</div>

<jsp:include page="includes/footer.jsp" />
