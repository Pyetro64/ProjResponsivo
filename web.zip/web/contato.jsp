<%@page import="models.UserBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Recupera a sessão atual sem forçar nova instância (false)
    HttpSession sessaoContato = request.getSession(false);
    UserBean usuarioLogado = (sessaoContato != null) ? (UserBean) sessaoContato.getAttribute("user") : null;
%>

<div class="container" style="margin-top: 80px; margin-bottom: 50px; max-width: 600px;">
    <h2>Contato</h2>

    <%-- Mensagens de Feedback baseadas na resposta do Servlet --%>
    <% if ("success".equals(request.getParameter("status"))) { %>
        <p style="padding: 12px; background-color: #dcfce7; color: #166534; border-radius: 4px; font-weight: bold; margin-bottom: 20px;">
            Mensagem enviada com sucesso! Entraremos em contato em breve.
        </p>
    <% } else if ("error".equals(request.getParameter("status"))) { %>
        <p style="padding: 12px; background-color: #fee2e2; color: #991b1b; border-radius: 4px; font-weight: bold; margin-bottom: 20px;">
            Erro ao enviar a mensagem. Tente novamente mais tarde.
        </p>
    <% } %>

    <%-- Formulário integrado que despacha os blocos de texto para o endpoint do ContactServlet --%>
    <form action="${pageContext.request.contextPath}/contato/enviar" method="POST" style="padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0;">
        
        <div class="form-group" style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Nome</label>
            <%-- Inteligência de Sessão: Se o usuário estiver logado, exibe o nome e bloqueia o campo para edição --%>
            <input required type="text" name="name" class="form-control" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;"
                   value="<%= usuarioLogado != null ? usuarioLogado.getName() : "" %>">
        </div>

        <div class="form-group" style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Email</label>
            <%-- Inteligência de Sessão: Se o usuário estiver logado, exibe o e-mail e bloqueia o campo --%>
            <input required type="email" name="email" class="form-control" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;"
                   value="<%= usuarioLogado != null ? usuarioLogado.getEmail() : "" %>">
        </div>

        <div class="form-group" style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Assunto</label>
            <input type="text" name="subject" class="form-control" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;" placeholder="Ex: Dúvidas sobre o Portfólio">
        </div>

        <div class="form-group" style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 5px; font-weight: bold;">Mensagem</label>
            <textarea required name="message" rows="5" class="form-control" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc; resize: vertical;" placeholder="Escreva aqui os detalhes da sua solicitação..."></textarea>
        </div>

        <button class="btn btn-primary" type="submit" style="background: #47b2e4; border: none; padding: 10px 25px; border-radius: 4px; color: white; cursor: pointer; font-weight: bold;">
            Enviar Mensagem
        </button>
    </form>

</div>

<jsp:include page="includes/footer.jsp" />
