<%@page import="models.UserBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>LP2 - Projeto Responsivo Java</title>
        <!-- Favicon -->
        <link rel="icon" href="${pageContext.request.contextPath}/assets/img/favicon.png" type="image/png">
        <!-- Fontes do Google -->
        <link rel="stylesheet" href="https://googleapis.com">
        <!-- Estilo CSS Responsivo -->
        <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/all.min.css">
        <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style1.css">
    </head>
    <body>
        <header class="header">
            <nav class="navbar">
                <%-- BLOCO DE LÓGICA DE SESSÃO: Lê o estado do cliente no servidor --%>
                <%
                    // Captura a sessão atual sem instanciar uma nova caso esteja vazia (false)
                    HttpSession sessaoNavbar = request.getSession(false);
                    UserBean usuarioNav = (sessaoNavbar != null) ? (UserBean) sessaoNavbar.getAttribute("user") : null;
                    // Define dinamicamente o link do logotipo: se logado vai para o perfil, se visitante vai para a home
                    String homeUrl = (usuarioNav != null) ? "/profile" : "/pagina?p=home";
                %>
                <h2 class="logo"><a href="${pageContext.request.contextPath}<%= homeUrl %>">CodingNepal</a></h2>
                <input type="checkbox" id="menu-toggle" />
                <label for="menu-toggle" id="hamburger-btn">☰</label>
                <ul class="links">
                    
                    <%-- CONDICIONAL 1: SE O USUÁRIO NÃO ESTIVER LOGADO (Exibe Menu Público Padrão) --%>
                    <% if (usuarioNav == null) { %>
                        <li><a href="${pageContext.request.contextPath}/pagina?p=home">Início</a></li>
                        <li><a href="${pageContext.request.contextPath}/pagina?p=sobre">Sobre nós</a></li>
                        <li><a href="${pageContext.request.contextPath}/pagina?p=servicos">Serviços</a></li>
                        <li><a href="${pageContext.request.contextPath}/pagina?p=portfolio">Portfólio</a></li>
                        <li><a href="${pageContext.request.contextPath}/pagina?p=contato">Contate-nos</a></li>
                        <li>
                            <div class="buttons">
                                <a href="${pageContext.request.contextPath}/pagina?p=login" class="signin">Entrar</a>
                                <a href="${pageContext.request.contextPath}/pagina?p=register" class="signup">Inscreva-se</a>
                            </div>
                        </li>

                    <%-- CONDICIONAL 2: SE HOUVER UM USUÁRIO LOGADO --%>
                    <% } else { %>
                        
                        <%-- REQUISITO COMUM PARA 'usu' E 'adm': Exibe sempre o Contate-nos e Meu Perfil --%>
                        <li><a href="${pageContext.request.contextPath}/pagina?p=contato">Contate-nos</a></li>
                        <li><a href="${pageContext.request.contextPath}/profile">Meu Perfil</a></li>
                        
                        <%-- REQUISITO EXCLUSIVO: SE FOR ADMINISTRADOR LOGADO ('adm') --%>
                        <%-- Bloqueia a exibição visual de painéis de gestão para contas comuns --%>
                        <% if ("adm".equalsIgnoreCase(usuarioNav.getUserType())) { %>
                            <li><a href="${pageContext.request.contextPath}/pagina?p=admin_users">Usuários</a></li>
                            <li><a href="${pageContext.request.contextPath}/pagina?p=admin_messages">Mensagens</a></li>
                            <li><a href="${pageContext.request.contextPath}/pagina?p=admin_audit_log">Auditoria</a></li>
                        <% } %>
                        
                        <%-- REQUISITO COMUM DE SAÍDA: Botão Sair com o nome dinâmico do usuário/adm --%>
                        <li>
                            <div class="buttons">
                                <a href="${pageContext.request.contextPath}/login?action=logout" 
                                   class="signin" 
                                   style="background: #dc3545; line-height: 1.2; text-align: center; padding: 5px 15px;"
                                   onclick="return confirm('Deseja sair do sistema?')">
                                   Sair<br><span style="font-size: 0.8em; font-weight: normal;">(<%= usuarioNav.getName() %>)</span>
                                </a>
                            </div>
                        </li>
                    <% } %>
                    
                </ul>
            </nav>
        </header>
        <main>
