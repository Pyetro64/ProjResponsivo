<%@page contentType="text/html" pageEncoding="UTF-8"%>
</main>
  <footer>
      <p>&copy; 2026 CodingNepal - Todos os direitos reservados. Estruturado em Java Web MVC.</p>
  </footer>

</body>
</html>