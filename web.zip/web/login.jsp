<%@page import="models.UserBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Garante que o usuário logado seja redirecionado caso tente entrar na tela de login novamente
    HttpSession sessaoLogin = request.getSession(false);
    UserBean usuarioLogado = (sessaoLogin != null) ? (UserBean) sessaoLogin.getAttribute("user") : null;
    if (usuarioLogado != null) {
        response.sendRedirect(request.getContextPath() + "/profile");
        return;
    }

    // 🔍 ESTRUTURA DE CAPTURA DO ERRO (Híbrida: Request + Session)
    String erro = (String) request.getAttribute("login_error");
    if (erro == null && sessaoLogin != null) {
        erro = (String) sessaoLogin.getAttribute("login_error");
        if (erro != null) {
            sessaoLogin.removeAttribute("login_error"); // Limpa a mensagem da sessão após exibir (Evita bug de F5)
        }
    }
%>

<div class="container" style="margin-top: 80px; margin-bottom: 50px; max-width: 500px;">
    <h2>Acessar Sistema</h2>
  
    <%-- FEEDBACK 1: Mensagens de sucesso vindas de redirecionamentos externos via parâmetro --%>
    <% if ("registered".equals(request.getParameter("msg"))) { %>
        <p style="color: green; font-weight: bold; margin-bottom: 15px;">Registrado com sucesso. Faça login.</p>
    <% } else if ("password_reset".equals(request.getParameter("msg"))) { %>
        <p style="color: green; font-weight: bold; margin-bottom: 15px;">Senha redefinida com sucesso! Faça login com a nova senha.</p>
    <% } %>

    <%-- FEEDBACK 2: CORRIGIDO - Alertas de erros internos capturados dinamicamente --%>
    <% if (erro != null && !erro.trim().isEmpty()) { %>
        <p style="color: red; font-weight: bold; margin-bottom: 15px; background-color: #fee2e2; padding: 10px; border-radius: 4px; border: 1px solid #fca5a5;">
            <%= erro %>
        </p>
    <% } %>

    <!-- Formulário apontando para o endpoint do AuthServlet -->
    <form action="${pageContext.request.contextPath}/login" method="POST" style="padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0;">
        <div class="input-box" style="margin-bottom: 20px; position: relative;">
            <label style="display: block; margin-bottom: 5px; font-weight: 600;">E-mail</label>
            <input type="email" name="email" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
        </div>

        <div class="input-box" style="margin-bottom: 20px; position: relative;">
            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Senha</label>
            <input type="password" name="password" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;">
        </div>

        <%-- Link para Esqueci minha senha --%>
        <div style="text-align: right; margin-bottom: 20px;">
            <a href="${pageContext.request.contextPath}/pagina?p=forgot_password" style="color: #47b2e4; text-decoration: none; font-size: 0.9em; font-weight: 500;">
                Esqueci minha senha?
            </a>
        </div>

        <button type="submit" class="btn" style="width: 100%; background: #47b2e4; color: white; border: none; padding: 12px; border-radius: 4px; font-size: 1rem; font-weight: bold; cursor: pointer; transition: background 0.3s;">
            Entrar
        </button>

        <div class="login-register" style="text-align: center; margin-top: 20px; font-size: 0.9em;">
            <p>Não tem uma conta? <a href="${pageContext.request.contextPath}/pagina?p=register" style="color: #47b2e4; text-decoration: none; font-weight: bold;">Inscreva-se</a></p>
        </div>
    </form>
</div>

<jsp:include page="includes/footer.jsp" />
