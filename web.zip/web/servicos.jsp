<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="/includes/header.jsp" %>

<section class="services-section" style="padding: 60px 20px; color: white;">
    <div class="container text-center">
        <h2 style="font-size: 2.5rem; margin-bottom: 40px;">Nossos Serviços</h2>
        
        <div class="row g-4">
            <!-- Serviço 1 -->
            <div class="col-md-4">
                <div class="card h-100 bg-dark text-white border-info shadow">
                    <div class="card-body">
                        <i class="fas fa-mobile-alt fa-3x mb-3 text-info"></i>
                        <h5 class="card-title">Apps Mobile</h5>
                        <p class="card-text">Desenvolvimento nativo e híbrido para iOS e Android com as tecnologias mais modernas.</p>
                    </div>
                </div>
            </div>

            <!-- Serviço 2 -->
            <div class="col-md-4">
                <div class="card h-100 bg-dark text-white border-info shadow">
                    <div class="card-body">
                        <i class="fas fa-code fa-3x mb-3 text-info"></i>
                        <h5 class="card-title">Sistemas Web</h5>
                        <p class="card-text">Criação de plataformas robustas utilizando a arquitetura MVC para máxima performance.</p>
                    </div>
                </div>
            </div>

            <!-- Serviço 3 -->
            <div class="col-md-4">
                <div class="card h-100 bg-dark text-white border-info shadow">
                    <div class="card-body">
                        <i class="fas fa-paint-brush fa-3x mb-3 text-info"></i>
                        <h5 class="card-title">UI/UX Design</h5>
                        <p class="card-text">Interfaces intuitivas e focadas na experiência do usuário para garantir engajamento.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<%@include file="/includes/footer.jsp" %>
