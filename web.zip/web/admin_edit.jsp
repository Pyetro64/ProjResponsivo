<%@page import="models.UserBean"%>
<%@page import="models.UserDAO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Trava de Segurança Crítica: Impede acessos de usuários comuns (usu) ou visitantes anônimos
    HttpSession sessaoEdit = request.getSession(false);
    UserBean adminLogado = (sessaoEdit != null) ? (UserBean) sessaoEdit.getAttribute("user") : null;

    if (adminLogado == null || !"adm".equalsIgnoreCase(adminLogado.getUserType())) {
        response.sendRedirect(request.getContextPath() + "/pagina?p=home");
        return;
    }

    // Captura o ID do usuário que será editado enviado via parâmetro GET na URL
    String idParam = request.getParameter("id");
    UserBean usuarioEdicao = null;
    
    if (idParam != null) {
        try {
            UserDAO dao = new UserDAO();
            usuarioEdicao = dao.getUserById(Integer.parseInt(idParam));
        } catch (NumberFormatException e) {
            usuarioEdicao = null; // Previne quebras caso o ID enviado não seja um número válido
        }
    }

    // Fallback de Segurança: Se o ID for inválido ou o usuário não existir, aborta e volta para a lista
    if (usuarioEdicao == null) {
        response.sendRedirect(request.getContextPath() + "/pagina?p=admin_users");
        return;
    }
%>

<div class="container" style="margin-top: 80px; margin-bottom: 50px; max-width: 500px;">
    <h2>Editar Nível de Acesso</h2>
    <p style="color: #f8f9fa; margin-bottom: 20px;">Alterando as permissões de: <strong><%= usuarioEdicao.getName() %></strong></p>

    <!-- Formulário que dispara a atualização para o método doPost do AdminServlet -->
    <form action="${pageContext.request.contextPath}/admin/atualizar" method="post" style="background: #f8f9fa; padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0;">
        <%-- Campo oculto (hidden) para enviar o ID do usuário junto com a requisição POST --%>
        <input type="hidden" name="id" value="<%= usuarioEdicao.getId() %>">

        <div class="form-group" style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 8px; font-weight: bold; color: #333;">Nível de Acesso (user_type)</label>
            <select name="user_type" class="form-control" style="width: 100%; padding: 10px; border-radius: 4px; border: 1px solid #ccc;">
                <%-- Deixa marcada (selected) a opção atual que está salva no banco de dados --%>
                <option value="usu" <%= "usu".equalsIgnoreCase(usuarioEdicao.getUserType()) ? "selected" : "" %>>USU (Usuário Comum)</option>
                <option value="adm" <%= "adm".equalsIgnoreCase(usuarioEdicao.getUserType()) ? "selected" : "" %>>ADM (Administrador)</option>
            </select>
        </div>

        <div style="display: flex; gap: 10px;">
            <button class="btn btn-success" type="submit" style="background: #28a745; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">
                Salvar Alterações
            </button>
            <a class="btn btn-light" href="${pageContext.request.contextPath}/pagina?p=admin_users" style="background: #6c757d; color: white; text-decoration: none; padding: 10px 20px; border-radius: 4px; display: inline-block; text-align: center;">
                Cancelar
            </a>
        </div>
    </form>
</div>

<jsp:include page="includes/footer.jsp" />
