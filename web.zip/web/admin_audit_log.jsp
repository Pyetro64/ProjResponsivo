<%@page import="java.text.SimpleDateFormat"%>
<%@page import="models.AuditBean"%>
<%@page import="java.util.List"%>
<%@page import="models.AuditDAO"%>
<%@page import="models.UserBean"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Blinagem de Segurança Crítica: Impede acessos de usuários comuns (usu) ou visitantes anônimos
    HttpSession sessaoAdmin = request.getSession(false);
    UserBean adminLogado = (sessaoAdmin != null) ? (UserBean) sessaoAdmin.getAttribute("user") : null;

    if (adminLogado == null || !"adm".equalsIgnoreCase(adminLogado.getUserType())) {
        response.sendRedirect(request.getContextPath() + "/pagina?p=home");
        return;
    }

    // Instancia a camada de persistência e recupera os logs salvos
    AuditDAO auditDao = new AuditDAO();
    List<AuditBean> listaLogs = auditDao.getLogs();

    // Formatador de máscara de data e hora
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
%>

<div class="table-container" style="max-width: 1100px; margin: 80px auto 50px auto; padding: 0 15px;">
    <div class="d-flex justify-content-between align-items-center mb-4" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Log de Auditoria do Sistema</h2>

    </div>

    <% if (listaLogs != null && !listaLogs.isEmpty()) { %>
    <table class="admin-table" style="width: 100%; border-collapse: collapse; margin-top: 15px;">
        <thead>
            <tr style="background-color: #f4f6f9; text-align: left; border-bottom: 2px solid #e2e8f0;">
                <th style="padding: 12px;">Data/Hora</th>
                <th style="padding: 12px;">Usuário</th>
                <th style="padding: 12px;">Ação</th>
                <th style="padding: 12px;">Detalhes</th>
            </tr>
        </thead>
        <tbody>
            <% for (AuditBean log : listaLogs) {%>
            <tr style="border-bottom: 1px solid #e2e8f0;">
                <%-- Renderiza a estampa de tempo formatada em milissegundos pelo SimpleDateFormat --%>
                <td style="padding: 12px; white-space: nowrap;"><%= sdf.format(log.getTimestamp())%></td>
                <td style="padding: 12px;"><strong><%= log.getUsername()%></strong></td>
                <td style="padding: 12px;">
                    <span style="background: #6c757d; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; display: inline-block;">
                        <%= log.getActionType()%>
                    </span>
                </td>
                <td style="padding: 12px;"><%= log.getDetails()%></td>
            </tr>
            <% } %>
        </tbody>
    </table>
    <% } else { %>
    <%-- Caixa de aviso de ausência de registros --%>
    <p style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; font-weight: bold; border: 1px solid #f5c6cb;">
        Nenhum registro de auditoria encontrado.
    </p>
    <% }%>
</div>

<jsp:include page="includes/footer.jsp" />
