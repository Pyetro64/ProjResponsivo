// views/assets/js/admin_messages.js
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('messageModal');
    const closeBtn = document.querySelector('.close-modal');
    const readButtons = document.querySelectorAll('button[data-bs-target="#messageModal"]');

    readButtons.forEach(button => {
        button.addEventListener('click', function () {
            // 1. Pega os dados do botão
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const subject = this.getAttribute('data-subject');
            const message = this.getAttribute('data-message');

            const formattedMessage = message.replace(/<br\s*\/?>/gi, '\n');

            // 2. Preenche o modal
            document.getElementById('modal-id').textContent = id;
            document.getElementById('modal-name').textContent = name;
            document.getElementById('modal-subject').textContent = subject;
            document.getElementById('modal-message').textContent = formattedMessage;

            // 3. Mostra o modal
            modal.style.display = 'flex';

            // ---------------------------------------------------------
            // 4. MÁGICA DO AJAX: Avisa o PHP para mudar para "lida"
            // ---------------------------------------------------------
            // Seleciona a coluna de status (é a 5ª coluna, índice 4)
            const statusCell = this.closest('tr').children[4];

            // Só avisa o banco se ainda estiver como 'pendente'
            if (statusCell.textContent.trim().toLowerCase() === 'pendente') {

                // Envia a requisição invisível para a rota admin_markAsRead
                fetch('index.php?route=admin_markAsRead', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id })
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.sucesso) {
                            // Muda visualmente o texto na tabela sem precisar recarregar a página!
                            statusCell.textContent = 'Lida';
                        }
                    });
            }
        });
    });

    // Lógica para fechar no botão 'X'
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }

    // Lógica para fechar ao clicar fora da janela
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});