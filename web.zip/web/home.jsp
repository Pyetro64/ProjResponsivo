<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="/includes/header.jsp" />

<section class="hero-section">
    <div class="hero">
        <h2>Desenvolvimento de Aplicativos Móveis</h2>
        <p>
            Junte-se a nós no emocionante mundo da programação e transforme suas ideias em realidade. 
            Desbloqueie o mundo de possibilidades infinitas - aprenda a programar e moldar o futuro digital conosco.
        </p>
        <div class="buttons">
            <a href="${pageContext.request.contextPath}/pagina?p=register" class="join">Junte-se agora</a>
            <a href="${pageContext.request.contextPath}/pagina?p=sobre" class="learn">Saiba mais</a>
        </div>
    </div>
    <div class="img">
        <img src="${pageContext.request.contextPath}/assets/img/hero-bg.png" alt="Hero Image" title="Hero Image">
    </div>
</section>

<jsp:include page="/includes/footer.jsp" />