<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<div class="container" style="margin-top: 80px; margin-bottom: 50px;">
    <h2>Cadastro de Usuário</h2>
    <%-- FEEDBACK DE ERRO: Alertas de falhas na inserção capturados do escopo Request --%>
    <% if (request.getAttribute("error") != null) { %>
      <p style="color: red;"><%= request.getAttribute("error") %></p>
    <% } %>
    
    <!-- Formulário que despacha os dados cadastrais via POST para o endpoint do Servlet -->
    <form action="${pageContext.request.contextPath}/registrar" method="post">
        <div class="form-group">
            <label>Nome</label>
            <input required type="text" name="username" class="form-control">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input required type="email" name="email" class="form-control">
        </div>
        <div class="form-group">
            <label>Telefone</label>
            <input required type="text" name="phone" class="form-control">
        </div>
        <div class="form-group">
            <label>Senha</label>
            <input required type="password" name="password" class="form-control">
        </div>
        <button class="btn btn-success" type="submit">Cadastrar</button>
    </form>
    
    <!-- Atualizado para o formato seguro de parâmetros de página -->
    <p style="margin-top: 15px;">
        <a class="btn btn-light" href="${pageContext.request.contextPath}/pagina?p=home">Voltar</a>
    </p>
</div>

<jsp:include page="includes/footer.jsp" />
