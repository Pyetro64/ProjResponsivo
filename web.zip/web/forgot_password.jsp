<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<div class="container" style="margin-top: 80px; margin-bottom: 50px; max-width: 450px;">
    <h2>Recuperar Senha</h2>
    <p style="margin-bottom: 15px;">Informe seu e-mail e telefone cadastrados:</p>

    <%-- FEEDBACK VISUAL: Exibe caixas de alerta de Sucesso ou Erro vindos do Servlet --%>
    <% if (request.getAttribute("message") != null) {
            String type = (String) request.getAttribute("message_type");
            boolean isError = "error".equalsIgnoreCase(type);
    %>
    <div style="padding: 10px; margin-bottom: 15px; border-radius: 4px;
         background-color: <%= isError ? "#fee2e2" : "#dcfce7"%>;
         color: <%= isError ? "#991b1b" : "#166534"%>; font-weight: bold;">
        <%= request.getAttribute("message")%>
    </div>
    <% }%>
    <%-- Formulário que despacha os dados via POST para o endpoint do PasswordResetServlet --%>
    <form method="POST" action="${pageContext.request.contextPath}/recuperar-senha/solicitar" style="padding: 25px; border-radius: 8px; border: 1px solid #e2e8f0;">
        <div class="form-group" style="margin-bottom: 15px;">
            <label for="email" style="display: block; margin-bottom: 5px; font-weight: bold;">E-mail</label>
            <input type="email" id="email" name="email" required autocomplete="email" class="form-control" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;" placeholder="exemplo@email.com">
        </div>

        <div class="form-group" style="margin-bottom: 20px;">
            <label for="phone" style="display: block; margin-bottom: 5px; font-weight: bold;">Telefone</label>
            <input type="text" id="phone" name="phone" required class="form-control" style="width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc;" placeholder="(00) 00000-0000">
        </div>

        <div style="display: flex; gap: 10px;">
            <button class="btn btn-primary" type="submit" style="background: #47b2e4; border: none; padding: 10px 20px; border-radius: 4px; color: white; cursor: pointer; font-weight: bold;">
                Gerar Link de Recuperação
            </button>
            <a class="btn btn-light" href="${pageContext.request.contextPath}/pagina?p=login" style="background: #6c757d; color: white; text-decoration: none; padding: 10px 20px; border-radius: 4px;">
                Voltar
            </a>
        </div>
    </form>
</div>

<jsp:include page="includes/footer.jsp" />
