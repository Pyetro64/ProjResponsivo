<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="includes/header.jsp" %>
<section class="portfolio-section" style="padding: 60px 20px; color: white;">
    <div class="container text-center">
        <h2 style="font-size: 2.5rem; margin-bottom: 40px;">Nosso Portfólio</h2>
        <p style="max-width: 800px; margin: 0 auto 40px; line-height: 1.6;">
            Conheça alguns dos projetos desenvolvidos pela equipe — soluções modernas que unem design, tecnologia e inovação.
        </p>

        <div class="row g-4">
            <!-- Projeto 1 -->
            <div class="col-md-4">
                <div class="card h-100 bg-dark text-white border-info shadow">
                    <div class="card-body">
                        <img src="${pageContext.request.contextPath}/assets/img/portfolio1.png" title="Aplicativo de Delivery" style="width:100%; border-radius:8px; margin-bottom:15px;">
                        <h5 class="card-title">Aplicativo de Delivery</h5>
                        <p class="card-text">Plataforma mobile para pedidos online com rastreamento em tempo real e integração de pagamentos.</p>
                    </div>
                </div>
            </div>

            <!-- Projeto 2 -->
            <div class="col-md-4">
                <div class="card h-100 bg-dark text-white border-info shadow">
                    <div class="card-body">
                        <img src="${pageContext.request.contextPath}/assets/img/portfolio2.png" title="Sistema de Gestão Web" style="width:100%; border-radius:8px; margin-bottom:15px;">
                        <h5 class="card-title">Sistema de Gestão Web</h5>
                        <p class="card-text">Dashboard completo para controle de vendas, usuários e relatórios, com interface responsiva e intuitiva.</p>
                    </div>
                </div>
            </div>

            <!-- Projeto 3 -->
            <div class="col-md-4">
                <div class="card h-100 bg-dark text-white border-info shadow">
                    <div class="card-body">
                        <img src="${pageContext.request.contextPath}/assets/img/portfolio3.png" title="Website Institucional Moderno" style="width:100%; border-radius:8px; margin-bottom:15px;">
                        <h5 class="card-title">Website Institucional</h5>
                        <p class="card-text">Site corporativo moderno e otimizado para SEO, com design adaptável a todos os dispositivos.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<%@include file="includes/footer.jsp" %>


