<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="/includes/header.jsp" />

<section class="hero-section" style="text-align: center; justify-content: center; min-height: 80vh;">
    <div class="hero" style="max-width: 100%;">
        <h1 style="font-size: 6rem; color: #47b2e4; margin-bottom: 10px;">404</h1>
        <h2>Página Não Encontrada</h2>
        <p style="margin-top: 15px; margin-bottom: 30px; color: #c9c7c7;">
            A página que você está tentando acessar não existe ou foi movida.
        </p>
        <div class="buttons">
            <!-- Botão para retornar à página principal (home) -->
            <a href="${pageContext.request.contextPath}/pagina?p=home" class="join">Voltar para a Página Inicial</a>
        </div>
    </div>
</section>

<jsp:include page="/includes/footer.jsp" />