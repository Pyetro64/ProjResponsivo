<%@page import="java.util.List"%>
<%@page import="models.UserBean"%>
<%@page import="models.UserDAO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<jsp:include page="includes/header.jsp" />

<%
    // Blindagem ativa em nível de View (Impede renderização de HTML para invasores)
    HttpSession sessaoAdmin = request.getSession(false);
    UserBean adminLogado = (sessaoAdmin != null) ? (UserBean) sessaoAdmin.getAttribute("user") : null;

    if (adminLogado == null || !"adm".equalsIgnoreCase(adminLogado.getUserType())) {
        response.sendRedirect(request.getContextPath() + "/pagina?p=home");
        return;
    }

    // Busca a lista atualizada de usuários diretamente do Banco de Dados
    UserDAO dao = new UserDAO();
    List<UserBean> listaUsuarios = dao.getAllUsers();
%>

<div class="container" style="margin-top: 80px; margin-bottom: 50px;">
    <div class="admin-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>Gerenciamento de Usuários</h2>
        <span class="total-users" style="background: #e2e8f0; padding: 5px 10px; border-radius: 4px; font-weight: bold; color:#333;">
            Total: <%= listaUsuarios.size()%> usuário(s)
        </span>
    </div>

    <%-- Feedbacks de Alertas vindos da URL --%>
    <% if ("deleted".equals(request.getParameter("msg"))) { %>
    <p style="color: green; font-weight: bold;">Usuário removido com sucesso!</p>
    <% } else if ("error_delete".equals(request.getParameter("msg"))) { %>
    <p style="color: red; font-weight: bold;">Erro ao excluir o usuário (você não pode se excluir).</p>
    <% } else if ("success".equals(request.getParameter("msg"))) { %>
    <p style="color: green; font-weight: bold;">Nível de acesso atualizado com sucesso!</p>
    <% } %>

    <table class="admin-table" style="width: 100%; border-collapse: collapse; margin-top: 15px;">
        <thead>
            <tr style="background-color: #f4f6f9; text-align: left; border-bottom: 2px solid #e2e8f0;">
                <th style="padding: 12px;">ID</th>
                <th style="padding: 12px;">Nome</th>
                <th style="padding: 12px;">E-mail</th>
                <th style="padding: 12px; text-align: center;">Nível de Acesso</th>
                <th style="padding: 12px; text-align: center;">Ações</th>
            </tr>
        </thead>
        <tbody>
            <% for (UserBean u : listaUsuarios) {%>
            <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 12px;"><%= u.getId()%></td>
                <td style="padding: 12px;"><strong><%= u.getName()%></strong></td>
                <td style="padding: 12px;"><%= u.getEmail()%></td>
                <td style="text-align: center; padding: 12px;">
                    <span class="role-badge" style="padding: 4px 8px; border-radius: 4px; font-size: 0.85em; font-weight: bold; color: white; background-color: <%= "adm".equalsIgnoreCase(u.getUserType()) ? "#dc3545" : "#007bff"%>;">
                        <%= u.getUserType().toUpperCase()%>
                    </span>
                </td>
                <td style="text-align: center; padding: 12px;">
                    <div class="action-links" style="display: flex; justify-content: center; gap: 10px;">
                        <!-- Link para a tela de alteração de privilégios  -->
                        <a class="btn-edit" href="${pageContext.request.contextPath}/pagina?p=admin_edit&id=<%= u.getId()%>" style="text-decoration: none; color: #007bff;">✏️ Editar</a>

                        <% if (u.getId() != adminLogado.getId()) {%>
                        <!-- Dispara a ação de exclusão física passando o ID via GET para o Servlet Controlador -->
                        <a class="btn-delete" href="${pageContext.request.contextPath}/admin/deletar?id=<%= u.getId()%>"
                           style="text-decoration: none; color: #dc3545;"
                           onclick="return confirm('Excluir o usuário <%= u.getName()%>? Esta ação não pode ser desfeita.')">
                            🗑️ Excluir
                        </a>
                        <% } else { %>
                        <span class="self-tag" style="color: #6c757d; font-style: italic;">(Você)</span>
                        <% } %>
                    </div>
                </td>
            </tr>
            <% }%>
        </tbody>
    </table>
</div>

<jsp:include page="includes/footer.jsp" />
